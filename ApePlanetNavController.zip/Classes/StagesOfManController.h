#import <UIKit/UIKit.h>

@interface StagesOfManController: UIViewController {
    NSString *imageFileName;
}

- (id) initWithTitle: (NSString *) title andImage: (NSString *) imageName nextStage: (BOOL) b;
- (void) nextEvolutionaryStage;
@end
