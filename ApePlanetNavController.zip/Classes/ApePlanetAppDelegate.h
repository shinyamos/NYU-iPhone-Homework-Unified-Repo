//
//  ApePlanetAppDelegate.h
//  ApePlanet
//
//  Created by scholar on 7/14/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
@class StagesOfManController;

@interface ApePlanetAppDelegate : NSObject <UIApplicationDelegate> {
	NSArray *names;
	NSArray *images;
	UINavigationController *controller;
	NSMutableArray *a;
	UIWindow *window;
}

- (void) nextEvolutionaryStage;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@end

