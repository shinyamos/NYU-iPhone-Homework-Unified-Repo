#import "EvolutionStageView.h"
#import "StagesOfManController.h"

@implementation EvolutionStageView


- (id) initWithFrame: (CGRect) frame withImage: (NSString *) imageName controller: (StagesOfManController *) c {
	self = [super initWithFrame: frame];
	if (self != nil) {
		// Initialization code
		controller = c;
		self.backgroundColor = [UIColor whiteColor];
        
        
		//Call drawRect: when the bounds change.
		self.contentMode = UIViewContentModeRedraw;
        NSLog(@"StageView with image %@", imageName);
        UIImage *image = [UIImage imageNamed: imageName];

        UIImageView *imageHolder = [[UIImageView alloc] initWithImage: image];
        if (image == nil) {
            NSLog(@"could not find file %@", imageName);
            return nil;
        }
        NSLog(@" frame for image is %g %g", frame.origin.y, frame.size.height);
        // Scale image so that it fits into available space
        //TODO: How to get accurate height of title bar/available space?
        imageHolder.frame = CGRectMake(0, 0, 320, 420);
        [self addSubview: imageHolder];

	}
	return self;
}

- (void) drawRect: (CGRect) rect {
	// Drawing code
}

- (void) dealloc {
	[button release];
	[super dealloc];
}

@end
