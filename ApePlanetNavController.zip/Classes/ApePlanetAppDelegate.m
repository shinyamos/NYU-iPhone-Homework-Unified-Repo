#import "ApePlanetAppDelegate.h"
#import "StagesOfManController.h"

@implementation ApePlanetAppDelegate
@synthesize window;

- (void) applicationDidFinishLaunching: (UIApplication *) application {    
    //Make fullscreen
    UIApplication *app = [UIApplication sharedApplication];
	app.statusBarHidden = YES;
   
    // Override point for customization after application launch
	names = [NSArray arrayWithObjects:
		@"The Beginning",
		@"Way Way Back",
		@"Way Back",
		@"Recently",
		@"Now",
		nil
	];
	[names retain];
	
	images = [NSArray arrayWithObjects:
		@"Man01.jpg",
		@"Man02.jpg",
		@"Man03.jpg",
		@"Man04.jpg",
		@"Man05.jpg",
		nil
	];
    [images retain];

	a = [[NSMutableArray alloc] init];
	
	[a addObject: [[StagesOfManController alloc]
                   initWithTitle: [names objectAtIndex: 0]
                   andImage: [images objectAtIndex: 0]
                   nextStage: names.count > 1
	]];
	
	//Put the first station into the navigation controller.
	controller = [[UINavigationController alloc]
		initWithRootViewController: [a objectAtIndex: 0]];

	//Put the navigation controller into the window.
	CGRect f = [UIScreen mainScreen].bounds;
	window = [[UIWindow alloc] initWithFrame: f];
	[window addSubview: controller.view];
	[window makeKeyAndVisible];
}

- (void) nextEvolutionaryStage {
	NSUInteger i = controller.viewControllers.count;
	if (i == names.count) {
		//All the stations are already pushed.
		return;
	}
	
	if (a.count <= i) {
		//This stage is being pushed for the first time.
		[a addObject: [[StagesOfManController alloc]
                       initWithTitle: [names objectAtIndex: i]
                       andImage: [images objectAtIndex: i]
                       nextStage: i < names.count - 1
                       ]];
	}
	
	[controller pushViewController: [a objectAtIndex: i] animated: YES];
}

- (void) dealloc {
	[window release];

	for (StagesOfManController *c in a) {
		[c release];
	}
	[a release];
	
	[names release];
    [images release];
	[super dealloc];
}

@end
