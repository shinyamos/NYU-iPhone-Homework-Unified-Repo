#import <UIKit/UIKit.h>
@class StagesOfManController;

@interface EvolutionStageView: UIView {
	StagesOfManController *controller;
	UIButton *button;
}

- (id) initWithFrame: (CGRect) frame withImage: (NSString *) imageName controller: (StagesOfManController *) c;
@end
