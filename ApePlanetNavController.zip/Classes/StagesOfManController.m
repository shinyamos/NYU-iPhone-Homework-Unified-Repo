
#import "StagesOfManController.h"
#import "ApePlanetAppDelegate.h"
#import "EvolutionStageView.h"

@implementation StagesOfManController

//Called by the nextLevel method of class StationView.

- (void) nextEvolutionaryStage {
	UIApplication *a = [UIApplication sharedApplication];
	ApePlanetAppDelegate *d = a.delegate;
	[d nextEvolutionaryStage];
}

- (id) initWithTitle: (NSString *) title andImage: (NSString *) imageName nextStage: (BOOL) b{
	self = [super initWithNibName: nil bundle: nil];
	if (self != nil) {
		// Custom initialization
		self.title = title;
        imageFileName = imageName;
        NSLog(@"Init with image Name %@", imageFileName);
		
		if (b) {
			self.navigationItem.rightBarButtonItem =
				[[UIBarButtonItem alloc] initWithTitle: @"future"
					style: UIBarButtonItemStylePlain
					target: self
					action: @selector(nextEvolutionaryStage)
				];
		}
	}
	return self;
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

// Create a view hierarchy programmatically, without using a nib.
- (void) loadView {
	CGRect f = [UIScreen mainScreen].bounds;
	self.view = [[EvolutionStageView alloc] initWithFrame: f withImage: imageFileName controller: self];
}

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

// Allow orientations other than the default portrait orientation.
- (BOOL) shouldAutorotateToInterfaceOrientation: (UIInterfaceOrientation) interfaceOrientation {
    // Return YES for supported orientations
    return YES;
}

- (void) didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void) viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void) dealloc {
	[self.view release];
	[super dealloc];
}

@end
