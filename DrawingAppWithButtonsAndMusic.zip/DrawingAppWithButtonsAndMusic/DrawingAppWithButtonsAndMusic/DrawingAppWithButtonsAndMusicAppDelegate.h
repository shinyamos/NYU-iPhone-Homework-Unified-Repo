//
//  DrawingAppWithButtonsAndMusicAppDelegate.h
//  DrawingAppWithButtonsAndMusic
//
//  Created by Tekserve Rentals on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVAudioPlayer.h>
@class View;

@interface DrawingAppWithButtonsAndMusicAppDelegate : NSObject <UIApplicationDelegate> {
	View *view;
	UIWindow *window;
	AVAudioPlayer *player;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
- (void) startDrag: (id) sender;

@end


