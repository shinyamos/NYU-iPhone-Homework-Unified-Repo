//
//  DrawingAppWithButtonsAndMusicTests.h
//  DrawingAppWithButtonsAndMusicTests
//
//  Created by Tekserve Rentals on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface DrawingAppWithButtonsAndMusicTests : SenTestCase {
@private
    
}

@end
