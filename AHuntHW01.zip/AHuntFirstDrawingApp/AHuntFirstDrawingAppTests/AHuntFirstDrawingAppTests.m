//
//  AHuntFirstDrawingAppTests.m
//  AHuntFirstDrawingAppTests
//
//  Created by Andrew Hunt on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AHuntFirstDrawingAppTests.h"


@implementation AHuntFirstDrawingAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AHuntFirstDrawingAppTests");
}

@end
