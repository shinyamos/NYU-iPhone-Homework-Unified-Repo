//
//  AHuntFirstDrawingAppTests.h
//  AHuntFirstDrawingAppTests
//
//  Created by Andrew Hunt on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface AHuntFirstDrawingAppTests : SenTestCase {
@private
    
}

@end
