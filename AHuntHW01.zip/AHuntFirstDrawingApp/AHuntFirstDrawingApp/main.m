//
//  main.m
//  AHuntFirstDrawingApp
//
//  Created by Andrew Hunt on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    // Let's seed the random function so we get a different tree every time!
    srand(time(NULL));    
    
    int retVal = UIApplicationMain(argc, argv, nil, @"AHuntFirstDrawingAppAppDelegate");
    [pool release];
    return retVal;
}
