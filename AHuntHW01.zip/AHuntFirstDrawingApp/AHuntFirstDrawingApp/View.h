//
//  View.h
//  AHuntFirstDrawingApp
//
//  Created by Andrew Hunt on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define TO_RADIANS M_PI/180.0

@interface View : UIView {
    CGContextRef drawContext;
}

- (void) drawBranchOfLength: (float) length angle: (float) a;
- (float) randomRangeFromLow: (float) low toHigh: (float) h;
//- (void) drawCircle: (float) x: (float) y: (float) radius;
- (UIColor *) HSL2RGBWithHue:(double) h sat:( double) sl light:(double) l;


@end





//initWithFirstName: @"Barak" male: YES age: 49];
//
//- (id) initWithFirstName: (NSString *) f male: (BOOL) m age: (int) a;
