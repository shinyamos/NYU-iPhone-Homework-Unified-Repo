//
//  AHuntFirstDrawingAppAppDelegate.h
//  AHuntFirstDrawingApp
//
//  Created by Andrew Hunt on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface AHuntFirstDrawingAppAppDelegate : NSObject <UIApplicationDelegate> {
	View *view;
	UIWindow *window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
