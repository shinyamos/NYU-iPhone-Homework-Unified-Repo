//
//  ElasticCord.h
//  KittyTossV2
//
//  Created by Andrew Hunt on 7/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ElasticCord : UIView {
    CGPoint coreOrigin;
}

- (void) setOrigin: (CGPoint) point;
- (void) drawTo: (CGPoint) kittyCenter;

@end
