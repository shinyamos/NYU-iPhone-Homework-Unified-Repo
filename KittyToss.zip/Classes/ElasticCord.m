//
//  ElasticCord.m
//  KittyTossV2
//
//  Created by Andrew Hunt on 7/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ElasticCord.h"


@implementation ElasticCord

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void) setOrigin: (CGPoint) point {
    coreOrigin = point;
}
- (void) drawTo: (CGPoint) kittyCenter {
    CGContextRef drawContext;
    drawContext = UIGraphicsGetCurrentContext();
    CGContextMoveToPoint(drawContext, coreOrigin.x, coreOrigin.y); 
    CGContextSetRGBStrokeColor(drawContext, .8, .8, .8, 1.0);
    CGContextAddLineToPoint(drawContext, kittyCenter.x, kittyCenter.y);
    CGContextStrokePath(drawContext);
    
}



- (void)dealloc
{
    [super dealloc];
}

@end
