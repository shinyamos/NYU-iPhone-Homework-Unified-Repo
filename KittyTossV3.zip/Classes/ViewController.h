//
//  ViewController.h
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

//CADisplayLink requires QuartzCore.framework
#import <QuartzCore/QuartzCore.h>

@interface ViewController: UIViewController {
	CADisplayLink *displayLink;
}

@end
