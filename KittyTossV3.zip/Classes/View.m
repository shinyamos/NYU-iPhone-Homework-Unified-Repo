//
//  View.m
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import <QuartzCore/QuartzCore.h>
#import "KittyTossDelegate.h"

@implementation View

- (id) initWithFrame: (CGRect) frame {
    if ((self = [super initWithFrame: frame])) {
		// Initialization code
		self.backgroundColor = [UIColor grayColor];
        
        CGFloat w = 480; //self.bounds.size.width;
        CGFloat h = 320; //self.bounds.size.height;

        NSLog(@" width/height are %g %g", w, h);
        
        //TODO: Add wind
        //windForce = -.01;
        
        kittyInFlight = NO;
        shouldUpdateCord = NO;
        kittyDrag = NO;

        UIImage *kittyImage = [UIImage imageNamed: @"TestKitty01.png"];
        if (kittyImage == nil) {
            NSLog(@"NOPE! Could not create kittyImage");
        }
        
        kittySprite = [[UIImageView alloc] initWithImage: kittyImage];
        defaultKittyCenter = CGPointMake(
                                .2*w - kittyImage.size.width/2,
                                h - 4* kittyImage.size.height
                                );
        
        kittySprite.center = defaultKittyCenter;
        [self addSubview:kittySprite];
        
		//Create the kitty target
        CGFloat targetW = w/40;
        CGFloat targetH = h/10;
		frame = CGRectMake(w-targetW, .5 * h-targetH/2, targetW, targetH);
        kittyTargetRect = frame; 
		kittyTarget = [[UIView alloc] initWithFrame: frame];
		kittyTarget.backgroundColor = [UIColor redColor];
		[self addSubview: kittyTarget];
        
        
		frame = CGRectMake(w-targetW- 120, .5 * h-targetH/2, 120, targetH);
        UILabel *targetLabel = [[UILabel alloc] initWithFrame:frame];
        targetLabel.backgroundColor = [UIColor clearColor];
        targetLabel.text = @"Put Kitty here➩";
        [self addSubview:targetLabel];
        
        
        
        // create origin for elastic cord
        frame = CGRectMake(.2*w, .6*h, 10, 10);
		cordOrigin = [[UIView alloc] initWithFrame: frame];
		cordOrigin.backgroundColor = [UIColor whiteColor];
		[self addSubview: cordOrigin];

        cordOriginPoint = CGPointMake(frame.origin.x + 5, frame.origin.y + 5);
        
        // Make cord it's own class so it can draw itself 
        // init with origin point, kitty center
        
        frame = CGRectMake(0,0, w, h);
		elasticCord = [[ElasticCord alloc] initWithFrame: frame];
		elasticCord.backgroundColor = [UIColor clearColor];
        [elasticCord setOrigin: cordOriginPoint];
        
		[self addSubview: elasticCord];
        
        // Set up Slider
        //Set up Labels for slider
        UIFont *font = [UIFont systemFontOfSize: 18.0];
        
        NSString *gravityLabelText = @"Gravity";;
        CGSize minLabelSize = [gravityLabelText sizeWithFont: font];
        
        CGRect maxLabelFrame =  CGRectMake(w * 0.1, h*0.05, minLabelSize.width, minLabelSize.height);
        gravityLabel = [[UILabel alloc] initWithFrame: maxLabelFrame];
        
        gravityLabel.font =  font;
        gravityLabel.backgroundColor = [UIColor clearColor];
        gravityLabel.textColor = [UIColor whiteColor];
        gravityLabel.text = gravityLabelText;
        
        [self addSubview: gravityLabel];        

        // touch kitten to start the game
        //gravity can be adjusted between rounds only
        
        minGravity = 0.01;	
		maxGravity = 0.08;   
		gravityForce = minGravity + (maxGravity - minGravity)/2;
        
        CGSize s = frame.size;
        CGRect f = CGRectMake((.3 * s.width), s.height*0.025, .4 * s.width, s.height*0.1);
		gravitySlider = [[UISlider alloc] initWithFrame: f];
		gravitySlider.minimumValue = minGravity;
		gravitySlider.maximumValue = maxGravity;
		gravitySlider.value = gravityForce;
		gravitySlider.continuous = YES;	//the default
		
		gravitySlider.backgroundColor = self.backgroundColor;
		
		[gravitySlider addTarget:self
                   action: @selector(updateGravity:)
         forControlEvents: UIControlEventValueChanged];
		
		[self addSubview: gravitySlider];
        
        // reset button
        //Center the button in the view.
		CGSize buttonSize = CGSizeMake(100, 40);	//size of button
		
		CGRect buttonFrame = CGRectMake(
                              (w - buttonSize.width)/2,
                               h - buttonSize.height * 1,
                                        buttonSize.width,
                                        buttonSize.height
                              );
        
		button = [UIButton buttonWithType: UIButtonTypeRoundedRect];
		[button retain];
		button.frame = buttonFrame;
        button.alpha = 0;
        
		[button setTitleColor: [UIColor grayColor] forState: UIControlStateNormal];
		[button setTitle: @"Again!" forState: UIControlStateNormal];
        
		[button addTarget: self
                   action: @selector(reset:)
         forControlEvents: UIControlEventTouchUpInside
         ];
        
		[self addSubview: button];        
        
        
    }
    return self;
}

- (void) updateGravity: (id) sender {
    
    gravityForce = gravitySlider.value;
//    NSLog(@"Updated gravity force is %g", gravityForce);
    
}

- (void) kittySuccess:(id)sender {
    KittyTossDelegate *delegate = [UIApplication sharedApplication].delegate;
    [delegate happySound: self];
    [UIView animateWithDuration:3.5
                          delay: 0
                        options: UIViewAnimationCurveLinear
                     animations:^{
                         kittySprite.center = CGPointMake(520, kittyTargetRect.origin.y + kittyTargetRect.size.height/2);
                     }
                     completion:NULL
     ];
    button.alpha = 1;

}
    
- (void) reset: (id) sender {
    
//    NSLog(@"Time to update the game, bro!");
    kittyInFlight = NO;
    shouldUpdateCord = NO;
    kittyDrag = NO;
    kittySprite.center =  defaultKittyCenter;
    CGAffineTransformMakeRotation(0.0);
    [kittySprite setTransform: CGAffineTransformMakeRotation(0.0) ];
    [self setNeedsDisplay];
    KittyTossDelegate *delegate = [UIApplication sharedApplication].delegate;
    [delegate killAudio: self];
    button.alpha = 0;
    elasticCord.alpha = 1;

    
}


- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count > 0) {
		UITouch *t = [touches anyObject];

        // are they touching the kitty?
		CGPoint p = [t locationInView: self];

        CGRect kittyRect = CGRectMake(kittySprite.center.x - kittySprite.bounds.size.width/2, 
                                      kittySprite.center.y - kittySprite.bounds.size.height/2, 
                                      kittySprite.bounds.size.width, 
                                      kittySprite.bounds.size.height);
        
        if (CGRectContainsPoint(kittyRect, p) )
            {        
                kittyDrag = YES;
//                NSLog(@"Click on kitty!");
        
                kittySprite.center = p;	//Move the view to a new location.
                
                KittyTossDelegate *delegate = [UIApplication sharedApplication].delegate;
                [delegate kittyTouch: self];
            }
        else {
            NSLog(@"Nope, not clicking on the kitty");
        }
	}
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    if (kittyDrag){
        UITouch *t = [touches anyObject];
        CGPoint p = [t locationInView: self];
        kittySprite.center = p;	//Move the view to a new location.
        [self setNeedsDisplay];

    }
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (kittyDrag){
        kittyDrag = NO;
        NSLog(@"Time to launch the kitty!");
        
        CGFloat magicScaleFactor = 0.05; 
        dx = magicScaleFactor * (cordOriginPoint.x - kittySprite.center.x);  //0.75;
        dy = magicScaleFactor * (cordOriginPoint.y - kittySprite.center.y); //-5.0;
        kittyInFlight = YES;
        shouldUpdateCord = YES;
        KittyTossDelegate *delegate = [UIApplication sharedApplication].delegate;
        [delegate kittyToss: self];
        
//        NSLog(@" dx = %g dy %g", dx, dy );
        
    }
}

- (void) updateDisplay: (CADisplayLink *) displayLink {
    if (!kittyInFlight)
        return;

    
    // check for intersection with target
    CGRect intersection = CGRectIntersection(kittyTargetRect, CGRectMake(kittySprite.center.x-20, kittySprite.center.y-20, kittySprite.image.size.width, kittySprite.image.size.height)) ;
    
    if (intersection.size.width > 0)
    {
//        NSLog(@"XXXXXXXXXXXX HIT HIT HIT");
        [self kittySuccess:self];
        kittyInFlight = NO;
    }
    
    if (kittySprite.center.y - kittySprite.image.size.height >= self.bounds.size.height) {
        NSLog(@"time for kitty to DIE");
        kittyInFlight = NO;
        KittyTossDelegate *delegate = [UIApplication sharedApplication].delegate;
        [delegate kittySmack: self];
        button.alpha = 1;
        return;
    } else
    {
        // update kitty!
        //dx -= windForce;
        dy += gravityForce;

        kittySprite.center = CGPointMake(kittySprite.center.x + dx, kittySprite.center.y + dy);
        
        CGFloat kittyRotationFactor = 0.02 * (1.0 + 5.0 * gravityForce/(maxGravity- minGravity));
        
        
        CGAffineTransform newRotation = CGAffineTransformConcat (kittySprite.transform, CGAffineTransformMakeRotation(kittyRotationFactor) );
        [kittySprite setTransform: newRotation ];
        
        if (kittySprite.center.y > cordOriginPoint.y && shouldUpdateCord) {
            [self setNeedsDisplay];
        } else {
            shouldUpdateCord = NO;
        }
    }
    
    
}
    
// Only override drawRect: if you perform custom drawing.
- (void) drawRect: (CGRect) rect {
    [elasticCord drawTo: kittySprite.center]; 

//    [elasticCord drawTo: cordOrigin.bounds.origin]; 


}

- (void) dealloc {
    [kittySprite release];
    [kittyTarget release];
    [cordOrigin release];
	[super dealloc];
}


@end
