    //
//  ViewController.m
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "View.h"

@implementation ViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/


// Create a view hierarchy programmatically, without using a nib.
- (void) loadView {
	CGRect f = [UIScreen mainScreen].applicationFrame;
	self.view = [[View alloc] initWithFrame: f];
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.

- (void) viewDidLoad {
	[super viewDidLoad];

	displayLink = [CADisplayLink displayLinkWithTarget: self.view
		selector: @selector(updateDisplay:)
	];

	//Call move: every time the display is refreshed.
	[displayLink setFrameInterval: 1];

	NSRunLoop *loop = [NSRunLoop currentRunLoop];
	[displayLink addToRunLoop: loop forMode: NSDefaultRunLoopMode];
}



// Allow orientations other than the default portrait orientation.
- (BOOL) shouldAutorotateToInterfaceOrientation:
	(UIInterfaceOrientation) interfaceOrientation {

	// Return YES for supported orientations
	return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;// || interfaceOrientation == UIInterfaceOrientationPortrait;
}


- (void) didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];

	// Release any cached data, images, etc that aren't in use.
}

- (void) viewDidUnload {
	[super viewDidUnload];
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void) dealloc {
	NSRunLoop *loop = [NSRunLoop currentRunLoop];
	[displayLink removeFromRunLoop: loop forMode: NSDefaultRunLoopMode];
	[self.view release];
	[super dealloc];
}

@end
