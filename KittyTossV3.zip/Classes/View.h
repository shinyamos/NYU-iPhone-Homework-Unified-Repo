//
//  View.h
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ElasticCord.h"


@interface View : UIView {
    // screen assets
    UIImageView *kittySprite;
    ElasticCord *elasticCord;
    UIView *cordOrigin;
    UIView *kittyTarget;
    CGRect kittyTargetRect;
    CGPoint cordOriginPoint; 
    
    CGPoint defaultKittyCenter; 
    
    
	CGFloat dx, dy;	//direction and speed of ball's motion
    CGFloat windForce;
    
    BOOL kittyInFlight; 
    BOOL kittyDrag;
    BOOL shouldUpdateCord;
    
    // slider
	UISlider *gravitySlider;
    UILabel *gravityLabel;
    CGFloat gravityForce;

	CGFloat minGravity;	//of slider
	CGFloat maxGravity;

    UIButton *button;
    
}

- (void) updateDisplay: (CADisplayLink *) displayLink;
- (void ) kittySuccess: (id) sender;

@end
