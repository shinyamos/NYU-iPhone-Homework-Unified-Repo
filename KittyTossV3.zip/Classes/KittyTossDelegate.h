//
//  PongAppDelegate.h
//  Pong
//
//  Created by NYU User on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVAudioPlayer.h>
@class ViewController;

@interface KittyTossDelegate: NSObject <UIApplicationDelegate> {
	ViewController *viewController;
	UIWindow *window;
	AVAudioPlayer *player;
}
- (void) kittyTouch: (id) sender;
- (void) kittyToss: (id) sender;
- (void) kittySmack: (id) sender;
- (void) killAudio: (id) sender;
- (void) happySound: (id) sender;
- (void) playSoundFile: (NSString *) fileName loop: (int) loopCount;


@property (nonatomic, retain) IBOutlet UIWindow *window;
@end

