//
//  main.m
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"FlipAppDelegate");
	[pool release];
	return retVal;
}
