//
//  BigView.m
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BigView.h"
#import "TileView.h"

@implementation BigView


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code

        //DON'T FORGET THIS!! OR NO MAGIC FINGERS!
        self.multipleTouchEnabled = YES;
        
        
        self.backgroundColor = [UIColor whiteColor];        
        pointBegan = CGPointZero;
		pointMoved = CGPointZero;

        womanTiles = [[NSMutableArray alloc] init];
        manTiles = [[NSMutableArray alloc] init];
        
        for (int i=1; i<=5; i++)
        {
            NSString *manTileId = [NSString stringWithFormat: @"man0%d.jpg", i];
            TileView *manTile = [[TileView alloc] initWithImageName: manTileId ] ;
            [manTiles addObject: manTile ];
            NSString *womanTileId = [NSString stringWithFormat: @"woman0%d.jpg", i];
            [womanTiles addObject:  [[TileView alloc] initWithImageName: womanTileId ] ];
        }
        
        tileDefs = [NSArray arrayWithObjects:
                     manTiles, 
                     womanTiles,
                     nil
                     ];
        
		[womanTiles retain];
        [manTiles retain];
        [tileDefs retain];
        
		columnIndex = 0;	
        rowIndex = 0;
        maxColumns = 5; 
        maxRows = 2;
        beganPinch = NO;
        originalScaleFactor = 1.0; 
		[self addSubview: [manTiles objectAtIndex: columnIndex]];
	}
	return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
//    NSLog(@"touchesBegan:withEvent: touches.count == %u", touches.count);
    
	NSAssert1(touches.count > 0,
              @"touchesBegan:withEvent: touches.count == %u", touches.count);
	
    if (touches.count ==1) {
        UITouch *t = [touches anyObject];
        pointBegan = [t locationInView: self];
        timeBegan = t.timestamp;
    }

	else if (touches.count == 2) {
        beganPinch = YES;
        NSLog(@"PINCH BEGAN YES YES YES");
		NSArray *a = touches.allObjects;	//Copy the set into an array.
		original0 = [[a objectAtIndex: 0] locationInView: self];
		original1 = [[a objectAtIndex: 1] locationInView: self];
        CGFloat dx = original0.x - original1.x;
        CGFloat dy = original0.y - original1.y;
        originalPinchSize = hypotf(dx, dy);
    }

}


- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
    if (touches.count ==1) {
        UITouch *t = [touches anyObject];
        pointMoved = [t locationInView: self];
        timeMoved = t.timestamp;
    }
	else if (touches.count == 2) {
		NSArray *a = touches.allObjects;	//Copy the set into an array.
		current0 = [[a objectAtIndex: 0] locationInView: self];
		current1 = [[a objectAtIndex: 1] locationInView: self];
		
		[self setNeedsDisplay];
	}
}

- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {

    beganPinch = NO;
	if (touches.count == 2) 
    {
        originalScaleFactor = currentScaleFactor;
        return;
    }


    
    // Drawing code
	CGFloat horizontal = pointMoved.x - pointBegan.x;
	CGFloat vertical = pointMoved.y - pointBegan.y;
	CGFloat distance = hypotf(horizontal, vertical);
	CGFloat angle = atan2f(-vertical, horizontal) * 180 / M_PI;
	
    NSString *s;
    int swipeResult;
    UIViewAnimationOptions swipeType;
    
    //keep ref to current values
    NSUInteger lastColIndex = columnIndex;	
    NSUInteger lastRowIndex = rowIndex;	
    
    swipeResult = noSwipe;
    
	if (distance < 50) {
		s = @"too short to be a swipe";
        swipeResult = noSwipe;
	} else if (angle <= -135 ) {
		s = @"swipe ←";
        swipeResult = swipeLeft;
        swipeType = UIViewAnimationOptionTransitionFlipFromRight;
        columnIndex++;
	} else if (angle <= -45 ) {
		s = @"swipe ↓";
        swipeResult = swipeDown;
        swipeType = UIViewAnimationOptionTransitionCurlDown;
        rowIndex--;
	} else if (angle <= 45) {
		s = @"swipe →";
        swipeResult = swipeRight;
        swipeType = UIViewAnimationOptionTransitionFlipFromLeft;
        columnIndex--;
	} else if (angle <= 135 ) {
		s = @"swipe ↑";
        swipeResult = swipeUp;
        swipeType = UIViewAnimationOptionTransitionCurlUp;
        rowIndex++;
	} else {
		s = @"swipe ←";
        swipeResult = swipeLeft;
        swipeType = UIViewAnimationOptionTransitionFlipFromRight;
        columnIndex++;
	}
    BOOL outOfBounds = false; 
    
    // endless vertical flipping 
    if (rowIndex < 0) 
    {
        rowIndex = maxRows-1;
    }
    if (rowIndex >=  maxRows) 
    {
        rowIndex = 0;
    }
            
    // check out of bounds within strip
    if (columnIndex < 0) 
    {
        columnIndex = 0;
        outOfBounds = true;
    }
    if (columnIndex >=  maxColumns) 
    {
        columnIndex = maxColumns-1;
        outOfBounds = true;
    }
    
//    NSLog(@" FInal results is %@ row%d col%d", s, rowIndex, columnIndex);
    
    if (swipeResult == noSwipe || outOfBounds)
        return;
    
    // reset scale
    originalScaleFactor = 1.0;
    TileView *subView = [self.subviews objectAtIndex:0 ];
    subView.transform = CGAffineTransformMakeScale(originalScaleFactor, originalScaleFactor);
	
    NSArray *curRowDef = [tileDefs objectAtIndex:rowIndex];
    NSArray *lastRowDef = [tileDefs objectAtIndex: lastRowIndex];
    
	[UIView transitionFromView: [lastRowDef objectAtIndex: lastColIndex]
		toView: [curRowDef objectAtIndex: columnIndex]
		duration: 0.4
		options: swipeType
        completion: NULL
	];
}
	


- (void) drawRect: (CGRect) rect {
    if (!beganPinch)
        return;
    
    // compare distance at start from distance now, scale accordingly
    
	CGFloat dx = current0.x - current1.x;
	CGFloat dy = current0.y - current1.y;
	CGFloat currentDistance = hypotf(dx, dy);
	
    currentScaleFactor =  MAX(0.1, MIN(currentDistance/originalPinchSize * originalScaleFactor, 3.0));
    
    // scale subvivew, otherwise you can't the touches don't register!
    TileView *subView = [self.subviews objectAtIndex:0 ];
    subView.transform = CGAffineTransformMakeScale(currentScaleFactor, currentScaleFactor);
    
    
//    NSLog(@"Scale Factor = %f", currentScaleFactor);
    
}


- (void) dealloc {
	for (UIView *v in womanTiles) {
		[v release];
	}
	for (UIView *v in manTiles) {
		[v release];
	}
    
    [tileDefs release];
    [manTiles release];
	[womanTiles release];
	[super dealloc];
}

@end
