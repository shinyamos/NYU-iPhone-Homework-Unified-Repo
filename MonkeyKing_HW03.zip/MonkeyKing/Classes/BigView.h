//
//  BigView.h
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


enum {
    swipeLeft,
    swipeRight,
    swipeUp,
    swipeDown,
    noSwipe
    
};


@interface BigView: UIView {
	CGPoint pointBegan;	//beginning and current points of touch
	CGPoint pointMoved;

	CGPoint original0;
	CGPoint original1;
    CGFloat originalPinchSize;
    CGFloat currentScaleFactor;
    CGFloat originalScaleFactor; 
    
    
    
	CGPoint current0;
	CGPoint current1;
	
    
	NSTimeInterval timeBegan;
	NSTimeInterval timeMoved;
    
    //holds the two subviews we transtion between
    NSMutableArray *womanTiles;
    NSMutableArray *manTiles;
    NSArray *tileDefs; 
	
    
	//index in views of the currently displayed little view: 0 or 1
	int columnIndex;
    int rowIndex;
    
    NSUInteger maxColumns;
    NSUInteger maxRows;
    NSUInteger index;
    
    BOOL beganPinch;
    
    
}

@end
