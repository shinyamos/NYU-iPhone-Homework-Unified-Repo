//
//  TileView.m
//  Flip
//
//  Created by Tekserve Rentals on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TileView.h"


@implementation TileView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id) initWithImageName: (NSString *) imageName {
	UIImage *image = [UIImage imageNamed: imageName];
	if (image == nil) {
		NSLog(@"could not find file %@", imageName);
		return nil;
	}
    self = [super initWithImage: image];
	if (self != nil) {
		self.userInteractionEnabled = NO; // We want the big view to get all swipes
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

@end
