//
//  FlipAppDelegate.h
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BigView;

@interface FlipAppDelegate : NSObject <UIApplicationDelegate> {
	BigView *bigView;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@end

