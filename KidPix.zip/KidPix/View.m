//
//  View.m
//  KidPix
//
//  Created by Andrew Hunt on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import <AssetsLibrary/AssetsLibrary.h>

@implementation View

//- (id)initWithFrame:(CGRect)frame
//{
//    NSLog(@"view initted!");
//    if ((self = [super initWithFrame: frame])) {
//        self.backgroundColor = [UIColor grayColor];
//        self.scrollEnabled = YES;
//    }
//    return self;
//}

- (id) initWithFrame: (CGRect) frame controller: (ViewController *) c {
	if ((self = [super initWithFrame: frame]) != nil) {
        initFrame = frame;
		// Initialization code
        NSLog(@"view initted!");
        
        self.backgroundColor = [UIColor grayColor];
		viewController = c;
	}
	return self;
}

- (void) setAssetData: (NSMutableArray *) assetData 
{
    galleryItems = assetData;
    [self initTableView];
}

- (void) initTableView 
{
    NSLog(@"initTable View, oh yeah!");
    tableView = [[UITableView alloc]
                 initWithFrame: initFrame
                 style: UITableViewStylePlain
                 ];
    
    tableView.dataSource = self;
    tableView.delegate = viewController;
    
    //some of the default values inherited from class UIScrollView
    tableView.indicatorStyle = UIScrollViewIndicatorStyleDefault; //scroll bar
    tableView.showsVerticalScrollIndicator = YES;   //fade out when stopped
    tableView.scrollsToTop = YES;                   //click on status bar
    tableView.bounces = YES;                        //against top and bottom
    tableView.rowHeight = CELL_WIDTH;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

    
    
    //        tableView.separatorColor = [UIColor clearColor];
    tableView.backgroundColor = [UIColor grayColor];
    
    [self addSubview: tableView];
}

#pragma mark -
#pragma mark methods of protocol UITableViewDataSource

- (NSInteger) numberOfSectionsInTableView: (UITableView *) v {
	return 1;
}

- (NSInteger) tableView: (UITableView *) v
  numberOfRowsInSection: (NSInteger) section {
    
    NSInteger rowCount =  (NSInteger) (0.7 + [galleryItems count]/(float)THUMBS_PER_ROW);
    NSLog(@" number of rows in section = %d %g", rowCount, [galleryItems count]/(float)THUMBS_PER_ROW);
	return rowCount;
}


- (UITableViewCell *) tableView: (UITableView *) v
          cellForRowAtIndexPath: (NSIndexPath *) indexPath {
	
	static NSString *identifier = @"states";
	UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier: identifier];
	
	if (cell == nil) {
		cell = [[UITableViewCell alloc]
                initWithStyle: UITableViewCellStyleDefault
                reuseIdentifier: identifier
                ];
		[cell autorelease];
	}

    UIView *cellView = cell.contentView;
    

    NSUInteger i;
    
        //Have to purge previous image subViews from cell!
//    int subViewCount =  [[cellView subviews] count];
//    NSLog(@"subViewCount for cell are %d", subViewCount);
//        for (i=subViewCount-1; i > -1 ; i--)
//    {
//        [[[cellView subviews] objectAtIndex: i] removeFromSuperview];
//    }
    
   // cell.selectionStyle =  UITableViewCellSelectionStyleNone;;
    
    for (i=0; i< THUMBS_PER_ROW; i++)
    {
        int curAssetIdx = indexPath.row * THUMBS_PER_ROW + i;
        if (curAssetIdx >= [galleryItems count])
            break;
        
        ALAsset *curAsset = [galleryItems objectAtIndex: curAssetIdx];
        UIImage *image =  [UIImage imageWithCGImage:[curAsset thumbnail]];            
        UIImageView *imageView = [[UIImageView alloc] init];
        [imageView setUserInteractionEnabled:YES];
        
        [imageView initWithImage:image];
        
        
        CGRect imageHolder = CGRectMake(0, 0, CELL_WIDTH, CELL_WIDTH);
        imageView.bounds = imageHolder;
        imageView.center = CGPointMake((i % THUMBS_PER_ROW) * CELL_WIDTH + CELL_WIDTH/2, CELL_WIDTH/2);
        [cellView addSubview: imageView];
    }
	return cell;
}

- (void) showAssetInRow: (NSInteger ) rowNum andCol: (NSInteger) col 
{
    int curAssetIdx = rowNum * THUMBS_PER_ROW + col;
    ALAsset *curAsset = [galleryItems objectAtIndex: curAssetIdx];
    ALAssetRepresentation *assetRep = [curAsset defaultRepresentation];
    
    UIImage *image =  [UIImage imageWithCGImage:[assetRep fullScreenImage]];            
    
    UIImageView *imageView = [[UIImageView alloc] init];
    [imageView initWithImage: image];

    //TODO: Deal with orientation!
    NSLog(@"Zoom image has resolution %d",[assetRep orientation]);
    
    
    [self addSubview:imageView];
    
    
}



//// Only override drawRect: if you perform custom drawing.
//// An empty implementation adversely affects performance during animation.
//- (void)drawRect:(CGRect)rect
//{
//    NSLog(@"OH yeah, drawRect is called at least 1X");
////    [self grabGalleryGroups];
//}
////*/
//

- (void)dealloc
{
    [super dealloc];
}

@end
