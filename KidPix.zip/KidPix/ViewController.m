//
//  ViewController.m
//  KidPix
//
//  Created by Andrew Hunt on 8/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "View.h"

@implementation ViewController

//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
//{
//    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
//    if (self) {
//        // Custom initialization
//    }
//    return self;
//}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    
	CGRect f = [UIScreen mainScreen].applicationFrame;
	self.view = [[View alloc] initWithFrame: f controller: self];
    customView = (View *) self.view;
    
    // let's get started!
    galleryGroups = [[NSMutableArray alloc] init];   
    galleryItems = [[NSMutableArray alloc] init];   
    
    // generate gallery data 
    [self grabGalleryGroups];
}


- (void) grabGalleryGroups
{
    NSLog(@"OH yeah, grabGallery is called");
    
    library = [[ALAssetsLibrary alloc] init];
    [library retain];
    
    void *enumerationBlock = ^(ALAssetsGroup *group, BOOL *stop ) {
        // null for last group
        if (group) 
        {
            NSLog(@"got group! -> %@ %d", group, [group numberOfAssets]) ;
            [galleryGroups addObject:group]; 
        }  // nil means no more groups
        else
        {
            [self grabGalleryAssets];
        }
    };
    
    void *failureBlock =  ^(NSError *error) {
        [self showEmptyGalleryError:error];
    };
    
    
    [library enumerateGroupsWithTypes: ALAssetsGroupAll  
                           usingBlock: enumerationBlock
                         failureBlock: failureBlock    
     ];
    
    NSLog(@"Asset groups: %@", [galleryGroups count]);
}

- (void) showEmptyGalleryError: (NSError *) error
{
    NSLog(@"some kinda failure getting groups, Bummer! %d", [error code]);
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Gallery error!"
                                       message: @"You need to have pictures in your gallery to view them!"
                                      delegate: self
                             cancelButtonTitle: @"OK"
                             otherButtonTitles: nil	//salute to MS-DOS
             ];
	
	[alert show];    
    
}


- (void) grabGalleryAssets 
{
    __block int count = 0; 
    NSLog(@" got completion of Block operation!, let's grab some assets from group: %@", galleryGroups);
    void *assetEnumerationBlock = ^(ALAsset *result, NSUInteger index, BOOL *stop) {
        if (result) 
        {
            [result retain];
            //NSLog(@"got alasset %d, %@ %@", index, result, thumb );
            [galleryItems addObject: result];
            count++;
        }
        else 
        {
            NSLog(@" Got count %d assets, bailing on loop, ready to show!", count);
            [self allAssetsReady];
        }
    };
    
    // enumerate through assets (photos/vids) of group!
    
    ALAssetsGroup *group = [galleryGroups objectAtIndex:0];
    [group enumerateAssetsUsingBlock:assetEnumerationBlock];
    
    // all done with library, graçias!
    [library release];    
    
}

- (void) allAssetsReady
{
    NSLog(@"allAssetReady called %@", self.view);
    [customView setAssetData: galleryItems];
}

- (void)tableView:(UITableView *)tableViewRef didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // A case was selected, so push into the CaseDetailViewController
    UITableViewCell *cell = [tableViewRef cellForRowAtIndexPath:indexPath];
    
    NSLog(@"ROW WAS selected!%d", indexPath.row);
    [customView showAssetInRow: indexPath.row andCol: 0];
    
    if (![cell selectionStyle] == UITableViewCellSelectionStyleNone) {
        // Handle tap code here
    }
}


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
