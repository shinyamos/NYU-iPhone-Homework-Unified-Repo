//
//  View.h
//  KidPix
//
//  Created by Andrew Hunt on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

#define THUMBS_PER_ROW 3
#define THUMB_W 75.0
#define CELL_WIDTH 320/3.0      


@interface View : UIView <UITableViewDataSource> {
    ViewController *viewController;
    NSMutableArray *galleryItems; 
    UITableView *tableView;
    CGRect initFrame;
    NSInteger currentAsset;
}

- (id) initWithFrame: (CGRect) frame controller: (ViewController *) c;
- (void) initTableView ;
- (void) setAssetData: (NSMutableArray *) assetData;
- (void) showAssetInRow: (NSInteger ) rowNum andCol: (NSInteger) col; 
@end
