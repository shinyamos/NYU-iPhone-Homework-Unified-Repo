//
//  ViewController.h
//  KidPix
//
//  Created by Andrew Hunt on 8/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "View.h"

@interface ViewController : UIViewController <UITableViewDelegate> {
    NSMutableArray *galleryItems; 
    NSMutableArray *galleryGroups;
    ALAssetsLibrary *library;
    View *customView;
}
- (void) grabGalleryGroups; 
- (void) grabGalleryAssets; 
- (void) allAssetsReady;
- (void) showEmptyGalleryError: (NSError *) error;


@end
