//
//  main.m
//  KidPix
//
//  Created by Andrew Hunt on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"KidPixAppDelegate");
    [pool release];
    return retVal;
}
