//
//  KidPixAppDelegate.h
//  KidPix
//
//  Created by Andrew Hunt on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "ViewController.h"

@interface KidPixAppDelegate : NSObject <UIApplicationDelegate> {
    ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
